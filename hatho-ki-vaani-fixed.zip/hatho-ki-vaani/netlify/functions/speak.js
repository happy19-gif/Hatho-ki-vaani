/** Netlify Function equivalent of /api/speak.js. Keep ELEVENLABS_API_KEY in Netlify environment settings. */
exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: { Allow: 'POST' }, body: JSON.stringify({ error: 'Method not allowed' }) };
  const apiKey = process.env.ELEVENLABS_API_KEY;
  if (!apiKey) return { statusCode: 503, body: JSON.stringify({ error: 'Speech service is not configured.' }) };
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { body = {}; }
  const text = typeof body.text === 'string' ? body.text.trim() : '';
  const voiceId = typeof body.voiceId === 'string' ? body.voiceId.trim() : '';
  if (!text || text.length > 1200) return { statusCode: 400, body: JSON.stringify({ error: 'Text is required and must be 1–1200 characters.' }) };
  if (!voiceId || voiceId.length > 100 || !/^[a-zA-Z0-9_-]+$/.test(voiceId)) return { statusCode: 400, body: JSON.stringify({ error: 'A valid voiceId is required.' }) };
  try {
    const upstream = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
      method: 'POST', headers: { 'xi-api-key': apiKey, 'Content-Type': 'application/json', 'Accept': 'audio/mpeg' },
      body: JSON.stringify({ text, model_id: 'eleven_multilingual_v2', voice_settings: { stability: 0.5, similarity_boost: 0.75, use_speaker_boost: true } })
    });
    if (!upstream.ok) return { statusCode: 502, body: JSON.stringify({ error: 'Speech provider request failed.' }) };
    const audio = Buffer.from(await upstream.arrayBuffer());
    return { statusCode: 200, isBase64Encoded: true, headers: { 'Content-Type': 'audio/mpeg', 'Cache-Control': 'private, max-age=0, no-store', 'X-Content-Type-Options': 'nosniff' }, body: audio.toString('base64') };
  } catch (error) {
    console.error('Speech proxy failed:', error);
    return { statusCode: 502, body: JSON.stringify({ error: 'Speech service is temporarily unavailable.' }) };
  }
};
